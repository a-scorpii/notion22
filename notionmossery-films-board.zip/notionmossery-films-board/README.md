# notion - mossery films board

A Pen created on CodePen.io. Original URL: [https://codepen.io/satevls/pen/xxzMdyX](https://codepen.io/satevls/pen/xxzMdyX).

